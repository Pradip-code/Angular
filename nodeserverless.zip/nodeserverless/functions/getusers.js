const axios = require("axios");
exports.handler = function (event, context, callback) {
  const API_URL = "https://api.github.com/users";
  const CLIENT_ID = "086a118555764ef55554";
  const API_CLIENT_SECRET = "32c1d3384e9f3a95b20d01c5dce83a812ef91870";
  const url = `${API_URL}?client_id=${CLIENT_ID}&client_secret${API_CLIENT_SECRET}`;

  //send user res
  const send = (body) => {
    callback(null, {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers":
          "Origin, X-Request-With, Content-Type, Accept, Authorization",
      },
      body: JSON.stringify(body),
    });
  };
  //api call
  const getUsers = () => {
    axios
      .get(url)
      .then((res) => send(res.data))
      .catch((err) => send(err));
  };
  //method
  if (event.httpMethod == "GET") {
    getUsers();
  }
};
